    def handle_raw_data(self, symbol, resp, return_new):
        # open_time open high low close vol
        all_data = resp.json()[:-1] if not return_new else resp.json()
        _list = [(self.ts2_str(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5])) for k in
                      sorted(all_data, key=lambda d: int(d[0]), reverse=True)]
        return _list

    @staticmethod
    def ts2_str(ts):
        return time.strftime("%Y-%m-%d %H:%M", time.localtime(int(ts)/1000))